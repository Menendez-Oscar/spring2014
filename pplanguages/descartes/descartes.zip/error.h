#ifndef ERROR_h
#define ERROR_h

#include <iostream>
#include <stdlib.h>

class Error {

	public: Error(int);
			Error(int, std::string);

};
#endif
